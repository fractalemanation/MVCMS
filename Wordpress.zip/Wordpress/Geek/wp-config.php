<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'gikaka' );

/** MySQL database username */
define( 'DB_USER', 'giki' );

/** MySQL database password */
define( 'DB_PASSWORD', 'Password0365' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'h)cruWB.4XSV*KTV<pzt`:G5civHde;~QZ|cpdL(?9V| oK~cM%(.1J;}Ur.x7T1' );
define( 'SECURE_AUTH_KEY',  'Zhuiy{f>l2NT7VVONPJ@ey4<-Mpr-(b?8Y]=kj%?rNOFyvz|RsSQNB=vVz}$^tZ*' );
define( 'LOGGED_IN_KEY',    ')Q.=Pt[-yDs)?,ksl5WBd}f>W_S!UGBW(@M~DCeAwA`q-BEHfP=WiEJ9,]HQskML' );
define( 'NONCE_KEY',        'Q)9cE^AYV#TL?Y<nD^7S6kL|82<bx0=wh_/*(MLbUjMC<mW{6u;_J$jOqC;j+,))' );
define( 'AUTH_SALT',        '~|<BJy6.gmn*##Iiu,6$CRaU3LTAqy1sP=g(5KbvxMmEGr7Qtt!jEk)uIzD0c$cr' );
define( 'SECURE_AUTH_SALT', 'bUj+ @yS[@F94!Ne5{|Ud*>T_dOA/C<4TbAmGVb%~dt7bgWkWSi2~{c{u&0lY0jc' );
define( 'LOGGED_IN_SALT',   '@2|90q+BYL73$s=C/2npCP04@1BM*)B{b+ZQM7v;za_[QxrkOLPdM6 YkV,^5+]%' );
define( 'NONCE_SALT',       'u+ugXgZZ%`uM.9Dp;|X&Q/k#]51;Q4CuBOaW|ivuhaqEQLtc#i<VoE@S_`<Zu%CM' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

define('FS_METHOD', 'direct');
$GLOBALS['_wp_filesystem_direct_method'] = 'relaxed_ownership';


/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
