<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'fractalamanation' );

/** MySQL database username */
define( 'DB_USER', 'ekologia' );

/** MySQL database password */
define( 'DB_PASSWORD', 'Password0365' );

/** MySQL hostname */
define( 'DB_HOST', 'mysql.zzz.com.ua' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         't(o 8=0gdRon}p7K:oJ ZlZvyso$1_ Q2sG3GvAc,U%RTNu{G?vkVuYi(=b#@rB{' );
define( 'SECURE_AUTH_KEY',  'bAjc^SNXzy)x7cEPgUrs,|1/LRd/gD7sBcNN1XT+s*>tB]`|%7lUt:tA1-5:WsO$' );
define( 'LOGGED_IN_KEY',    '-bK%r%#HC-Mq-+`*aK.Tos:5>Du}`U@d2*c/N>FX-hjtsq~6] IL_vPZf><ksxD#' );
define( 'NONCE_KEY',        'xk*DZq/!I^pkD4%:fsCP[m^nBOr7ytVZKsw|p%|;K6*Q;h:d-J;N?]r^!vheAD:~' );
define( 'AUTH_SALT',        'eMT0]wg|`$4#uN`q7</|gr^YHW0b`-j6oML.$ 05nhjR0kH3%|z-9i~eHDLi{@#*' );
define( 'SECURE_AUTH_SALT', 'Ri+WlhMuYOTGHn.X)CMxnQ%~nv*U;A@lyBA)/a(-aG`GIsre9V2V@2pgqNybLmA2' );
define( 'LOGGED_IN_SALT',   'nyP%r*2M}g;q:KTsIg!x|j-R#U{t&zl;8GP&T5/$%uAdT%%87AA]=482W}[1iw%/' );
define( 'NONCE_SALT',       '*T3PEtGn~4i<)zRf1tcC+](>-`4G&x5U^QXwx7J_5ab@32Z}Rf#XrF5KdH27|9,d' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

define('FS_METHOD', 'direct');
$GLOBALS['_wp_filesystem_direct_method'] = 'relaxed_ownership';
define('DISABLE_WP_CRON', true);


/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );
